package edu.fatec.lp2.exercicio2.interfaces;

public interface Calculavel {
    public double calcularPreco();
}
