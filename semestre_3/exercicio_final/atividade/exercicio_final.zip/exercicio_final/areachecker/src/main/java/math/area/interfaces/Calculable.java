package math.area.interfaces;

public interface Calculable {
    public double calcularArea();
}
